class Config:
    SECRET_KEY = 'your_secret_key'
    SQLALCHEMY_DATABASE_URI = 'mysql://root:Drb2004.@localhost/home_service'
    SQLALCHEMY_TRACK_MODIFICATIONS = False