from flask import Flask
from flask_sqlalchemy import SQLAlchemy

# Initialize the SQLAlchemy object (shared across app)
db = SQLAlchemy()

def create_app():
    # Create the Flask app instance
    app = Flask(__name__,template_folder='templates')
    
    # Load config from config.py (class-based)
    app.config.from_object('config.Config')
    
    # Initialize the SQLAlchemy app with Flask app context
    db.init_app(app)

    # Import and register the blueprint
    from ..routes import main
    app.register_blueprint(main)

    return app
