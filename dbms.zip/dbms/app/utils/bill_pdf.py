from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter

def generate_bill_pdf(booking, user, amount, path):
    c = canvas.Canvas(path, pagesize=letter)
    c.setFont("Helvetica-Bold", 16)
    c.drawString(100, 750, "Service Invoice")

    c.setFont("Helvetica", 12)
    c.drawString(100, 720, f"Invoice ID: INV-{booking.id}")
    c.drawString(100, 700, f"Customer: {user.fullname}")
    c.drawString(100, 680, f"Email: {user.email}")
    c.drawString(100, 660, f"Service: {booking.service_type}")
    c.drawString(100, 640, f"Date: {booking.date}")
    c.drawString(100, 620, f"Amount Due: ₹{amount}")
    c.drawString(100, 600, f"Status: {booking.status}")

    c.drawString(100, 550, "Thank you for choosing our service!")
    c.save()
