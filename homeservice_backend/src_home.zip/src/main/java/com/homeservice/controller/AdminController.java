package com.homeservice.controller;

import com.homeservice.dto.Dto;
import com.homeservice.model.User;
import com.homeservice.service.BookingService;
import com.homeservice.service.UserService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.stream.Collectors;

/**
 * ADMIN CONTROLLER
 * GET /api/admin/stats   → dashboard stats
 * GET /api/admin/users   → all users
 */
@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final UserService userService;
    private final BookingService bookingService;

    private User requireAdmin(HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) throw new RuntimeException("UNAUTHORIZED");
        User user = userService.findById(userId).orElseThrow(() -> new RuntimeException("UNAUTHORIZED"));
        if (!"admin".equals(user.getRole())) throw new RuntimeException("FORBIDDEN");
        return user;
    }

    /** GET /api/admin/stats → dashboard numbers */
    @GetMapping("/stats")
    public ResponseEntity<?> getStats(HttpSession session) {
        try {
            requireAdmin(session);
            return ResponseEntity.ok(Map.of(
                "totalBookings",  bookingService.getTotal(),
                "pendingBookings", bookingService.countPending(),
                "totalCustomers", userService.countCustomers(),
                "totalProviders", userService.countProviders()
            ));
        } catch (RuntimeException e) {
            int status = "UNAUTHORIZED".equals(e.getMessage()) ? 401 : 403;
            return ResponseEntity.status(status).body(new Dto.MessageResponse(e.getMessage(), false));
        }
    }

    /** GET /api/admin/users → all users (safe, no passwords) */
    @GetMapping("/users")
    public ResponseEntity<?> getAllUsers(HttpSession session) {
        try {
            requireAdmin(session);
            var users = userService.getAllUsers().stream()
                .map(userService::toResponse).collect(Collectors.toList());
            return ResponseEntity.ok(users);
        } catch (RuntimeException e) {
            int status = "UNAUTHORIZED".equals(e.getMessage()) ? 401 : 403;
            return ResponseEntity.status(status).body(new Dto.MessageResponse(e.getMessage(), false));
        }
    }

    /** GET /api/admin/providers → list of providers (for dropdown) */
    @GetMapping("/providers")
    public ResponseEntity<?> getProviders(HttpSession session) {
        try {
            requireAdmin(session);
            var providers = userService.getAllProviders().stream()
                .map(userService::toResponse).collect(Collectors.toList());
            return ResponseEntity.ok(providers);
        } catch (RuntimeException e) {
            int status = "UNAUTHORIZED".equals(e.getMessage()) ? 401 : 403;
            return ResponseEntity.status(status).body(new Dto.MessageResponse(e.getMessage(), false));
        }
    }
}
