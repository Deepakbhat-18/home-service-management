package com.homeservice.controller;

import com.homeservice.dto.Dto;
import com.homeservice.model.User;
import com.homeservice.service.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * AUTH CONTROLLER
 *
 * @RestController = @Controller + @ResponseBody
 *   → every method automatically returns JSON, not HTML
 *
 * @RequestMapping("/api/auth") = all routes in this class start with /api/auth
 *
 * ResponseEntity<T> = lets you control both the response body AND the HTTP status code
 *   ResponseEntity.ok(data)           → 200 OK
 *   ResponseEntity.badRequest().body  → 400 Bad Request
 *   ResponseEntity.status(401).body   → 401 Unauthorized
 *
 * HttpSession = Spring injects this - represents the user's browser session.
 * We store the user ID in the session after login.
 */
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UserService userService;

    /**
     * POST /api/auth/register
     * Body: { "email": "...", "fullname": "...", "password": "...", ... }
     * Returns: { "message": "...", "success": true }
     */
    @PostMapping("/register")
    public ResponseEntity<Dto.MessageResponse> register(@Valid @RequestBody Dto.RegisterRequest req) {
        try {
            userService.register(req);
            return ResponseEntity.ok(new Dto.MessageResponse("Registration successful! Please login.", true));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest()
                .body(new Dto.MessageResponse(e.getMessage(), false));
        }
    }

    /**
     * POST /api/auth/login
     * Body: { "email": "...", "password": "..." }
     * Returns: { "id": 1, "email": "...", "fullname": "...", "role": "customer", "message": "..." }
     *
     * On success, stores userId in HTTP session so future requests are authenticated.
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Dto.LoginRequest req, HttpSession session) {
        return userService.login(req.getEmail(), req.getPassword())
            .map(user -> {
                // Save user ID in server-side session
                // Browser will store the session cookie automatically
                session.setAttribute("userId", user.getId());
                session.setAttribute("userRole", user.getRole());
                return ResponseEntity.ok((Object) new Dto.LoginResponse(
                    user.getId(), user.getEmail(), user.getFullname(),
                    user.getRole(), "Login successful"
                ));
            })
            .orElseGet(() -> ResponseEntity.status(401)
                .body(new Dto.MessageResponse("Invalid email or password", false)));
    }

    /**
     * POST /api/auth/logout
     * Clears the server session.
     */
    @PostMapping("/logout")
    public ResponseEntity<Dto.MessageResponse> logout(HttpSession session) {
        session.invalidate();
        return ResponseEntity.ok(new Dto.MessageResponse("Logged out successfully", true));
    }

    /**
     * GET /api/auth/me
     * Returns the currently logged-in user's info.
     * Frontend calls this on page load to check if user is already logged in.
     */
    @GetMapping("/me")
    public ResponseEntity<?> getCurrentUser(HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return ResponseEntity.status(401)
                .body(new Dto.MessageResponse("Not logged in", false));
        }
        return userService.findById(userId)
            .map(user -> ResponseEntity.ok((Object) userService.toResponse(user)))
            .orElseGet(() -> ResponseEntity.status(401)
                .body(new Dto.MessageResponse("Session invalid", false)));
    }
}
