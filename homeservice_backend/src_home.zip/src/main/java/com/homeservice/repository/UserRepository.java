package com.homeservice.repository;

import com.homeservice.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

/**
 * REPOSITORY - Database access for Users
 *
 * Spring Data JPA reads the method name and generates SQL automatically.
 *   findByEmail("a@b.com")  →  SELECT * FROM users WHERE email = 'a@b.com'
 *   findByRole("provider")  →  SELECT * FROM users WHERE role = 'provider'
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    List<User> findByRole(String role);
    long countByRole(String role);
    boolean existsByEmail(String email);
}
